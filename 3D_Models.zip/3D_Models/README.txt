It is possible that the models in the 
folder are not at an absolutely perfect scale, 
as they may have been slightly adjusted—either 
during export or within the printer's software.